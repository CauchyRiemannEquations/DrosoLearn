from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess,sys
R=Path(__file__).resolve().parents[1]/'outputs/DrosoLearn'
def read(n):return json.loads((R/n).read_text(encoding='utf8'))
def sha(n):return hashlib.sha256((R/n).read_bytes()).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=R)
archive=read('results/objective_pathways_archive_validation.json');assert archive['status']=='passed'
for name,digest in archive['current_file_sha256'].items():assert sha(name)==digest,name
qa=read('results/objective_pathways_presentation_validation.json')
for key in ('document_sha256','additional_file_sha256'):
    for name,digest in qa[key].items():assert sha(name)==digest,name
reg=read('results/registration_objective_pathways_v1.json');assert len(reg['source_files'])==25
for name,digest in reg['source_files'].items():assert sha(name)==digest,name
v=read('results/objective_pathways_v1/verification.json');s=read('results/objective_pathways_v1/summary.json')
assert v['status']=='passed' and v['counts']['arrays']==16 and v['counts']['parent_trial_records_checked']==192000
assert read('docs/repository-status.json')['continuation_automation']['status']=='PAUSED'
expected={'README.md','docs/research-roadmap.md','docs/repository-status.json',
    'docs/objective-pathways-findings.md','docs/objective-pathways-reproduction.md',
    'results/objective_pathways_archive_validation.json','results/objective_pathways_presentation_validation.json',
    'results/objective_pathways_publication_proof.json','scripts/check_objective_pathways_archive.py','scripts/render_objective_pathways.py'}
expected|={'results/objective_pathways_presentation_attempt01.json','results/objective_pathways_presentation_attempt01.zip'}
expected|={'results/objective_pathways_presentation_consumer_attempt01.json','results/objective_pathways_presentation_consumer_attempt01.zip'}
for folder in ('results/objective_pathways_v1','results/objective_pathways_figures_v1'):
    expected|={p.relative_to(R).as_posix() for p in (R/folder).iterdir() if p.is_file()}
if '--stage' in sys.argv:subprocess.run(['git','add','--',*sorted(expected)],cwd=R,check=True)
if '--remote' not in sys.argv:
    staged=set(git('diff','--cached','--name-only').decode().splitlines());assert staged==expected,(staged^expected)
    for name in staged:assert hashlib.sha256(git('show',':'+name)).hexdigest()==sha(name),name
    assert not git('diff','--name-only').decode().strip()
    assert not git('ls-files','--others','--exclude-standard').decode().splitlines()
    subprocess.run(['git','-c','core.whitespace=blank-at-eol,blank-at-eof,space-before-tab,cr-at-eol','diff','--cached','--check'],cwd=R,check=True)
    print(f'Precommit seal passed:{len(archive["current_file_sha256"])}snapshot hashes,25sources,{len(staged)}exactpaths.')
    if '--commit' in sys.argv:
        subprocess.run(['git','commit','-m','Complete saved U/P direction size and choice-reward accounting with independent verification'],cwd=R,check=True)
        subprocess.run(['git','tag','objective-pathways-v1'],cwd=R,check=True)
        subprocess.run(['git','push','origin','main','objective-pathways-v1'],cwd=R,check=True)
else:
    head=git('rev-parse','HEAD').decode().strip();tag='objective-pathways-v1'
    assert git('status','--porcelain').decode()=='' and git('rev-parse',tag).decode().strip()==head
    def api(suffix):return json.loads(subprocess.check_output(['gh','api','repos/CauchyRiemannEquations/DrosoLearn'+suffix],cwd=R))
    repo=api('');main=api('/git/ref/heads/main')['object']['sha'];remote_tag=api('/git/ref/tags/'+tag)['object']['sha']
    assert repo['private'] is True and main==remote_tag==head
    proof={'status':'passed','verified_at_utc':datetime.now(timezone.utc).isoformat(),'repository':repo['html_url'],
        'visibility':'private','local_head':head,'remote_main':main,'completion_tag':tag,'remote_tag_commit':remote_tag,
        'working_tree_clean':True,'archive_sha256':sha('results/objective_pathways_archive_validation.json'),
        'current_snapshot_hashes_rechecked':len(archive['current_file_sha256']),'all25_frozen_sources_unchanged':True,
        'saved_parent_trial_records_independently_reconstructed':192000,'numeric_arrays_independently_checked':16,
        'choice_reward_strata_checked':34560,'all_prior_completed_bytes_and_failures_preserved':True,
        'new_training_rng_graph_optimization_calls':0,'automatic_continuation_paused':True,
        'original_phase5_preserved':True,'stored_outside_repository_to_keep_tree_clean':True}
    with (Path(__file__).parent/'objective_pathways_completion_remote_validation.json').open('x',encoding='utf8',newline='\n') as h:
        json.dump(proof,h,ensure_ascii=False,indent=2);h.write('\n')
    print(json.dumps(proof))
