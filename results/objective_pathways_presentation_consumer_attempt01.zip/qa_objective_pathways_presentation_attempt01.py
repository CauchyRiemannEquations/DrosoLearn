"""Read-only presentation audit of saved arrays, rows, paths and exact units.

No scientific producer, verifier, graph, RNG, learner or solver is imported.
The separately completed scientific full replay is not repeated here.
"""
from pathlib import Path
from datetime import datetime, timezone
import csv
import hashlib
import json
import sys
import xml.etree.ElementTree as ET
from zipfile import ZipFile

import numpy as np
from PIL import Image

R = Path(__file__).resolve().parents[1] / 'outputs/DrosoLearn'
S = R / 'results/objective_pathways_v1'
F = R / 'results/objective_pathways_figures_v1'
TOPS = ('real','rewired','ann'); REPS = ('raw','identity')
METHODS = ('shared','isolated','feedback_selective','balanced','gated_balanced','gated_self_blend','gated_uniform','gated_probability')
PAIRS = ((6,4),(7,4),(7,6))
COMPONENTS = ('state','scalar','direction','control_only_Go','candidate_only_Go','neither_Go')
DOCS = ('docs/objective-pathways-findings.md','docs/objective-pathways-reproduction.md','README.md','docs/research-roadmap.md','docs/repository-status.json')
def read(path):return json.loads((R/path).read_text(encoding='utf8'))
def sha(path):return hashlib.sha256((R/path).read_bytes()).hexdigest()
def check(actual,expected,label):
    a,b=np.asarray(actual),np.asarray(expected)
    assert a.shape==b.shape,label+' shape'
    assert np.isfinite(a).all() and np.allclose(a,b,atol=1e-9,rtol=1e-9),label
def scalar(actual,expected,label):
    if expected is None:assert actual is None,label
    else:check(actual,expected,label)
def sigmoid(z):return 1./(1.+np.exp(-np.clip(z,-40.,40.)))
def shapley(cells):
    out=[]
    for bit in (4,2,1):
        value=np.zeros_like(cells[...,0,:])
        for subset in range(8):
            if subset&bit:continue
            value+=(1./6. if subset.bit_count()==1 else 1./3.)*(cells[...,subset|bit,:]-cells[...,subset,:])
        out.append(value)
    return np.stack(out,-2)
def tables(text):
    result=[];current=[]
    for line in text.splitlines()+['']:
        if line.startswith('|'):
            if not line.startswith('|---'):current.append([x.strip() for x in line.strip('|').split('|')])
        elif current:result.append(current);current=[]
    return result
def report_values(row,values,label):
    numbers=[float(x.replace('%p','').replace('%','')) for x in row]
    assert len(numbers)==len(values),label
    assert np.allclose(numbers,values,atol=5.01e-7,rtol=0.),label

reg=read('results/registration_objective_pathways_v1.json');cfg=read('configs/objective_pathways_v1.json')
summary=read('results/objective_pathways_v1/summary.json');verified=read('results/objective_pathways_v1/verification.json')
assert summary['status']=='completed' and verified['status']=='passed'
assert len(reg['source_files'])==25 and len(reg['parent_files'])==16
for group in ('source_files','parent_files'):
    for path,digest in reg[group].items():assert sha(path)==digest,(group,path)
assert verified['registration_sha256']==sha('results/registration_objective_pathways_v1.json')
assert verified['summary_sha256']==sha('results/objective_pathways_v1/summary.json')
with np.load(S/'arrays.npz',allow_pickle=False) as h:a={key:h[key] for key in h.files}
with np.load(R/'results/objective_learning_v1/arrays.npz',allow_pickle=False) as h:p={key:h[key] for key in h.files}
assert len(a)==16 and len(p)==215
assert a['probability_changes'].shape==(3,2,8,10,400,4)
for name in ('model_seeds','schedules','targets','uniforms'):assert np.array_equal(a[name],p[name]),name
q=a['probability_changes'];y=2*a['targets']-1
check(q,p['trial_correct_probability_delta'],'saved original probability effects')
check(a['margin_changes'],p['trial_aligned_margin_delta'],'saved original margin effects')
check(sigmoid(a['source_logits_before']),p['trial_probabilities'],'saved original source probabilities')
assert np.array_equal(a['reference_post'],np.all(p['trial_known_before'][:,:,4]!=0,-1))
for mi in (6,7):assert np.array_equal(a['reference_post'],np.all(p['trial_known_before'][:,:,mi]!=0,-1))
with (S/'measurements.csv').open(encoding='utf8',newline='') as h:
    reader=csv.DictReader(h);assert len(reader.fieldnames)==15;rows=list(reader)
assert len(rows)==2160
lookup={}
for row in rows:
    key=tuple(row[name] for name in ('topology','representation','comparison','seed','destination_group','component'))
    assert key not in lookup;lookup[key]=row
families=summary['families'];assert len(families)==18
row_count=0
for ti,top in enumerate(TOPS):
    for ri,rep in enumerate(REPS):
        for ci,(nm,cm) in enumerate(PAIRS):
            family=families[(ti*2+ri)*3+ci]
            assert (family['topology'],family['representation'],family['candidate'],family['control'])==(top,rep,METHODS[nm],METHODS[cm])
            for si,seed in enumerate(a['model_seeds']):
                at=(ti,ri,ci,si);c=(ti,ri,cm,si);n=(ti,ri,nm,si)
                record=family['seeds'][si];assert record['seed']==seed
                post=a['reference_post'][ti,ri,si];cases=p['trial_actions'][c]+2*p['trial_actions'][n]
                assert np.array_equal(cases,a['pair_action_cases'][at])
                e=post&(cases==3);assert np.array_equal(e,a['bridge_eligible'][at])
                check(record['case_counts'],[np.count_nonzero(post&(cases==i)) for i in range(4)],'all four actual action cases')
                assert record['reference_post_trials']==post.sum() and record['both_Go_trials']==e.sum()
                cells=a['bridge_q_cells'][at]
                check(cells[e,0],q[c][e],'control actual crossed endpoint')
                check(cells[e,7],q[n][e],'candidate actual crossed endpoint')
                for field,values in (('bridge_q_shapley',cells),('bridge_positive_shapley',np.maximum(cells,0.)),('bridge_negative_shapley',np.maximum(-cells,0.))):
                    check(a[field][at],shapley(values),'saved eight-cell '+field)
                own=np.eye(4,dtype=bool)[a['schedules'][si]]
                for gi,(group,destination) in enumerate(zip(('own','other'),(own,~own))):
                    sums=[[],[],[]]
                    for ki,component in enumerate(COMPONENTS):
                        if ki<3:
                            quantities=[a[key][at][:,ki] for key in ('bridge_q_shapley','bridge_positive_shapley','bridge_negative_shapley')]
                            count=int(e.sum())
                        else:
                            code=(1,2,0)[ki-3];selected=post&(cases==code);fact=q[c] if code==1 else q[n]
                            sign=-1. if code==1 else 1. if code==2 else 0.
                            quantities=[sign*v*selected[:,None] for v in (fact,np.maximum(fact,0.),np.maximum(-fact,0.))]
                            count=int(selected.sum())
                        vals=[float(v[destination].sum()) for v in quantities]
                        row=lookup[top,rep,family['comparison'],str(seed),group,component]
                        assert int(row['reference_post_trials'])==post.sum() and int(row['both_Go_trials'])==e.sum() and int(row['component_trials'])==count
                        for field,value in zip(('probability_signed_sum','positive_mass_allocation','negative_mass_allocation'),vals):scalar(float(row[field]),value,'CSV '+field)
                        for j,(field,value) in enumerate(zip(('endpoint_contribution','positive_endpoint_allocation','negative_endpoint_allocation'),vals)):
                            scalar(float(row[field]),value/4.,'CSV endpoint unit');sums[j].append(value/4.)
                        row_count+=1
                    for field,values in zip(('component_endpoint_contributions','component_positive_endpoint_allocations','component_negative_endpoint_allocations'),sums):check(record[field][gi],values,'all component ledger cells')
                    postmask=post[:,None]&destination;premask=~post[:,None]&destination
                    delta=q[n]-q[c]
                    for field,value in (('factual_post_endpoint_difference',delta[postmask].sum()/4.),('factual_pre_endpoint_difference',delta[premask].sum()/4.),
                        ('factual_post_positive_endpoint_difference',(np.maximum(q[n],0.)-np.maximum(q[c],0.))[postmask].sum()/4.),
                        ('factual_post_negative_endpoint_difference',(np.maximum(-q[n],0.)-np.maximum(-q[c],0.))[postmask].sum()/4.)):
                        scalar(record[field][gi],value,'all group facts '+field)
                diag=a['factual_pair_diagnostics'][at]
                for side,path in enumerate((c,n)):
                    src=a['schedules'][si,e];index=np.arange(len(src));z=a['source_logits_before'][path][e]
                    go=p['trial_probabilities'][path][e];g=p['trial_update_factors'][path][e]
                    norm=np.linalg.norm(p['trial_directions'][path][e],axis=-1);f=p['trial_actual_influence'][path][e]
                    other=~np.eye(4,dtype=bool)[src];aligned=y[src,None]*y*f
                    wanted=np.column_stack((y[src]*z,np.where(y[src]>0,go,1-go),go*(1-go),np.abs(g),np.abs(g)*norm,
                        f[index,src],np.where(other,aligned,0.).sum(-1)/3.,norm,p['trial_rewards'][path][e],go,
                        y[src]*g*f[index,src],np.where(other,y*g[:,None]*f,0.).sum(-1)/3.))
                    check(diag[e,side],wanted,'all paired factual diagnostic fields')
                assert np.all(diag[~e]==0.)
                scalar(record['diagnostic_means'],diag[e].mean(0) if e.any() else [[None]*12]*2,'diagnostic equal-subset means')
                div=np.flatnonzero(p['trial_actions'][n]!=p['trial_actions'][c])
                assert record['first_actual_action_divergence']==(int(div[0]+1) if len(div) else None)
                check(p['trial_rewards'][n][e],p['trial_rewards'][c][e],'paired obtained reward identity')
                scalar(record['final_endpoint_difference'],float((y*(p['checkpoint_probabilities'][n][-1]-p['checkpoint_probabilities'][c][-1])).mean()),'endpoint original checkpoint')
            for field,value in family['means'].items():
                values=[record[field] for record in family['seeds']]
                def avg(items):
                    if isinstance(items[0],list):return [avg(list(col)) for col in zip(*items)]
                    defined=[v for v in items if v is not None]
                    return float(np.mean(defined)) if defined else None
                expected=avg(values)
                if expected is None:assert value is None
                else:check(value,expected,'all eighteen equal-seed family means '+field)
assert row_count==2160
paths=summary['actual_paths'];assert len(paths)==48
strata_count=0
for ti,top in enumerate(TOPS):
    for ri,rep in enumerate(REPS):
        for mi,method in enumerate(METHODS):
            family=paths[(ti*2+ri)*8+mi];assert (family['topology'],family['representation'],family['method'])==(top,rep,method)
            for si,seed in enumerate(a['model_seeds']):
                record=family['seeds'][si];at=(ti,ri,mi,si);src=a['schedules'][si]
                act=p['trial_actions'][at];reward=p['trial_rewards'][at];g=p['trial_update_factors'][at];go=p['trial_probabilities'][at]
                step=np.abs(g)*np.linalg.norm(p['trial_directions'][at],axis=-1);own=np.eye(4,dtype=bool)[src]
                unknown=(p['trial_known_before'][at]==0)&~own;changes=q[at]
                assert np.array_equal(act,a['uniforms'][si]<go) and np.array_equal(reward,act*y[src])
                check(g,.1*(act-go)*reward,'actual recorded signed size')
                initial=np.where(y>0,p['checkpoint_probabilities'][at][0],1-p['checkpoint_probabilities'][at][0])
                final=np.where(y>0,p['checkpoint_probabilities'][at][-1],1-p['checkpoint_probabilities'][at][-1])
                check(record['initial_correct_probabilities'],initial,'all480 initial probabilities')
                check(record['final_correct_probabilities'],final,'all480 final probabilities')
                scalar(record['final_mean'],float(final.mean()),'all480 final means')
                check(changes.sum(0),final-initial,'saved effect endpoint closure')
                masks={'all':np.ones(400,bool),'pre':~a['reference_post'][ti,ri,si],'post':a['reference_post'][ti,ri,si]}
                for phase,mask in masks.items():
                    count=int(mask.sum());correct=np.where(y[src]>0,go,1-go)
                    want={'trials':count,'Go':int(act[mask].sum()),'NoGo':int(np.count_nonzero(act[mask]==0)),
                        'reward_positive':int(np.count_nonzero(reward[mask]>0)),'reward_negative':int(np.count_nonzero(reward[mask]<0)),
                        'obtained_reward_sum':int(reward[mask].sum()),'expected_obtained_reward_sum':float((go*y[src])[mask].sum()),
                        'source_Go_probability_mean':float(go[mask].mean()) if count else None,
                        'correct_source_probability_mean':float(correct[mask].mean()) if count else None,
                        'head_path_l2':float(step[mask].sum()),'head_squared_l2':float((step[mask]**2).sum()),
                        'unknown_other_damage':float(np.maximum(-changes,0.)[unknown&mask[:,None]].sum()),
                        'own_endpoint_contribution':float(changes[own&mask[:,None]].sum()/4.),
                        'other_endpoint_contribution':float(changes[~own&mask[:,None]].sum()/4.)}
                    assert set(record['phases'][phase])==set(want)
                    for key,value in want.items():scalar(record['phases'][phase][key],value,'all480 phase path '+key)
                assert len(record['source_action_reward_strata'])==72
                for stratum in record['source_action_reward_strata']:
                    keep=masks[stratum['phase']]&(src==stratum['source'])&(act==stratum['action'])&(reward==stratum['reward'])
                    count=int(keep.sum());assert stratum['trials']==count
                    want={'obtained_reward_sum':int(reward[keep].sum()),'absolute_scalar_sum':float(np.abs(g[keep]).sum()),
                        'head_path_l2':float(step[keep].sum()),'source_probability_mean':float(go[keep].mean()) if count else None,
                        'own_endpoint_contribution':float(changes[own&keep[:,None]].sum()/4.),
                        'other_endpoint_contribution':float(changes[~own&keep[:,None]].sum()/4.)}
                    for key,value in want.items():scalar(stratum[key],value,'all34560 source/action/reward strata '+key)
                    strata_count+=1
            scalar(family['final_mean'],float(np.mean([r['final_mean'] for r in family['seeds']])),'all48 final family means')
assert strata_count==34560
plot=read('results/objective_pathways_figures_v1/plotted_values.json')
assert plot['comparison_order']==summary['comparison_order'] and plot['component_order']==summary['component_order']
check(plot['primary_component_endpoint_contributions'],[f['means']['component_endpoint_contributions'] for f in families[:3]],'all primary plotted factors')
check(plot['all_final_endpoint_differences'],[[r['final_endpoint_difference'] for r in f['seeds']] for f in families],'all180 plotted seed endpoints')
primary_paths=[paths[i] for i in (4,6,7)]
rewards=[[np.mean([r['phases']['post'][key] for r in f['seeds']]) for key in ('Go','reward_positive','reward_negative','head_path_l2')] for f in primary_paths]
check(plot['primary_post_reward_and_movement_means'],rewards,'plotted reward and realized movement values')
provenance=read('results/objective_pathways_figures_v1/provenance.json')
for path,digest in provenance['source_sha256'].items():assert sha(path)==digest,path
for name,digest in provenance['artifact_sha256'].items():assert sha('results/objective_pathways_figures_v1/'+name)==digest,name
dimensions={}
for name in ('factor-accounting.png','all-contrasts.png','choice-reward-paths.png'):
    with Image.open(F/name) as img:dimensions[name]=list(img.size)
findings=(R/DOCS[0]).read_text(encoding='utf8');document_tables=tables(findings);assert len(document_tables)==7
for ci,family in enumerate(families[:3]):
    components=np.asarray(family['means']['component_endpoint_contributions']);total=components.sum(0)*100
    report_values(document_tables[0][ci+1][1:],list(total[:5])+[family['means']['final_endpoint_difference']*100],'primary total table')
    for gi in range(2):
        want=list(components[gi,:3]*100)+[components[gi,3:5].sum()*100,family['means']['factual_post_endpoint_difference'][gi]*100,
            family['means']['factual_post_positive_endpoint_difference'][gi]*100,family['means']['factual_post_negative_endpoint_difference'][gi]*100]
        report_values(document_tables[1][ci*2+gi+1][2:],want,'own/other help and harm table')
    for side in range(2):
        d=family['means']['diagnostic_means'][side]
        report_values(document_tables[2][ci*2+side+1][2:],[d[j] for j in (1,9,3,4,5,6,7)],'paired diagnostic table')
    counts=np.sum([r['case_counts'] for r in family['seeds']],axis=0)
    report_values(document_tables[3][ci+1][1:5],counts,'summed actual action cases')
    assert document_tables[3][ci+1][5]==str([r['first_actual_action_divergence'] for r in family['seeds']])
for i,family in enumerate(primary_paths):
    def mean(phase,key):return np.mean([r['phases'][phase][key] for r in family['seeds']])
    values=[mean('post',key) for key in ('Go','reward_positive','reward_negative','obtained_reward_sum','head_path_l2')]+[mean('all','head_path_l2'),mean('all','unknown_other_damage')]
    report_values(document_tables[4][i+1][1:],values,'reward movement and unknown table')
    means=np.mean([r['final_correct_probabilities'] for r in family['seeds']],axis=0)*100
    report_values(document_tables[5][i+1][1:],list(means)+[means.mean()],'four source endpoints table')
for i,family in enumerate(families):
    components=np.asarray(family['means']['component_endpoint_contributions']).sum(0)*100
    report_values(document_tables[6][i+1][3:],[family['means']['final_endpoint_difference']*100,*components[:3],components[3:5].sum()],'all18 report decomposition means')
assert '291' in (R/DOCS[1]).read_text(encoding='utf8') and '176' in findings and '115' in findings
tests=read('results/objective_pathways_prefreeze_validation.json')
cases=ET.parse(R/tests['test_receipts'][0]['path']).findall('.//testcase')
assert len(cases)==len({(c.get('classname'),c.get('name')) for c in cases})==291
assert not any(c.find(kind) is not None for c in cases for kind in ('failure','error','skipped'))
assert tests['unique_passed_tests']==291 and tests['new_unique_passed_tests']==176 and tests['unchanged_related_regression_passed_tests']==115
assert tests['development_failure_artifacts']==[]
status=read('docs/repository-status.json')
assert status['objective_pathways_completed'] is True and status['continuation_automation']['status']=='PAUSED'
assert status['phase5_completed'] is True and status['bounded_phase5_deliverables_completed'] is True
assert status['level4_similarity_supported'] is False and status['shared_neural_mechanism_verified'] is False and status['education_effect_tested'] is False
assert status['current_findings_document']==DOCS[0]
assert 'objective_pathways_v1' in (R/'README.md').read_text(encoding='utf8') and 'objective_pathways_v1' in (R/'docs/research-roadmap.md').read_text(encoding='utf8')
publication=read('results/objective_pathways_publication_proof.json');metadata=read('results/objective_pathways_v1/metadata.json')
assert publication['status']=='passed' and publication['checked_at_utc']<metadata['started_at_utc']<metadata['completed_at_utc']<verified['verified_at_utc']<provenance['rendered_at_utc']
if '--write' in sys.argv:
    additional=set(reg['source_files'])|set(reg['parent_files'])|{'results/registration_objective_pathways_v1.json',
        'results/objective_pathways_baseline_preservation.json','results/objective_pathways_prefreeze_validation.json',tests['test_receipts'][0]['path'],
        'results/objective_pathways_publication_proof.json','scripts/render_objective_pathways.py'}
    for folder in (S,F):additional|={p.relative_to(R).as_posix() for p in folder.iterdir() if p.is_file()}
    draft_note='results/objective_pathways_presentation_attempt01.json'
    if (R/draft_note).exists():
        additional.add(draft_note);note=read(draft_note)
        draft_zip='results/objective_pathways_presentation_attempt01.zip';additional.add(draft_zip)
        # The exact initial presentation is retained as a separate attempt;
        # no frozen science or completed parent bytes were changed.
        with ZipFile(R/draft_zip) as archive:assert len(archive.namelist())>=5
    result={'status':'passed','study_id':'objective_pathways_v1','checked_at_utc':datetime.now(timezone.utc).isoformat(),
        'document_sha256':{path:sha(path) for path in DOCS},'additional_file_sha256':{path:sha(path) for path in sorted(additional)},
        'checks':{'all18_families180_comparison_paths_and480_actual_paths_recomputed_from_saved_values':True,
            'all34560_actual_source_action_reward_strata_and_null_denominators_checked':True,
            'all2160_CSV_rows15_columns_and16_numeric_arrays_bound':True,
            'saved_eight_cell_symmetric_signed_positive_negative_allocations_checked':True,
            'own_other_partition_unpaired_actions_and_all_endpoint_sums_checked':True,
            'all_report_table_values_and_percentage_point_units_checked':True,
            'all180_plotted_seed_endpoints_and_factor_reward_movement_values_checked':True,
            'three_PNGs_visually_inspected_with_unobscured_reward_bars':True,
            'source25_parent16_and291_unique_passed_tests_unchanged':True,
            'new_scientific_replay_learning_graph_RNG_or_solver_calls':0,
            'no_unique_causal_generalization_human_or_shared_mechanism_claim':True,
            'original_phase5_complete_postphase5_followup_scope_and_paused_automation_retained':True},
        'presentation_values':{'primary_component_endpoint_contributions':[f['means']['component_endpoint_contributions'] for f in families[:3]],
            'primary_endpoint_differences':[f['means']['final_endpoint_difference'] for f in families[:3]],
            'primary_post_obtained_reward_movement_means':rewards,'eligible_both_Go_trials':int(a['bridge_eligible'].sum()),
            'actual_source_action_reward_strata_checked':strata_count,'CSV_records_checked':row_count},'png_dimensions':dimensions}
    out=R/'results/objective_pathways_presentation_validation.json'
    with out.open('x',encoding='utf8',newline='\n') as h:json.dump(result,h,ensure_ascii=False,indent=2);h.write('\n')
    print('Presentation QA passed and exclusive receipt written: '+hashlib.sha256(out.read_bytes()).hexdigest())
else:print('Read-only presentation arithmetic and tables passed; no receipt written.')
