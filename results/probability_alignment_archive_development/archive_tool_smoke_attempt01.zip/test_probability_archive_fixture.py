"""Invented archive receipts only; no parent records, graph or optimization."""
import copy
from datetime import datetime, timezone
import importlib.util
import json
from pathlib import Path
import tempfile
import sys

base = Path(__file__).resolve().parent.parent
repo = base / 'outputs/DrosoLearn'
sys.path.insert(0, str(repo / 'src'))
spec = importlib.util.spec_from_file_location('archive_fixture_target', repo / 'scripts/check_probability_alignment_archive.py')
mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)

counts = {'numeric_arrays': 27, 'measurement_records': 900, 'saved_reference_records': 24000,
    'saved_reference_destination_effects': 96000, 'eligible_actual_Go_records': 7,
    'candidate_destination_effects': 140, 'candidate_single_update_evaluations': 35,
    'new_optimization_calls': 10, 'unique_uniform_optimizations': 3, 'state_probability_optimizations': 7}
checks = {'numeric_arrays_checked': 27, 'saved_reference_records_checked': 24000,
    'saved_reference_destination_effects_checked': 96000, 'measurement_records_checked': 900,
    'eligible_actual_Go_records_checked': 7, 'candidate_destination_effects_checked': 140,
    'independent_ambient_support_reoptimizations': 10, 'independent_active_faces_per_support': 16,
    'independent_legacy_support_reoptimizations': 3,
    'new_training_trials': 0, 'new_random_draws': 0, 'fresh_model_constructions': 0,
    **{k: True for k in ('head_prefixes_and_factual_scalar_effects_checked',
    'own_prefeedback_observed_signs_and_full_gate_checked', 'all_five_same_state_signed_updates_checked',
    'uniform_and_probability_global_support_independently_reoptimized',
    'legacy_balanced_global_support_independently_reoptimized',
    'signed_finite_probability_failures_and_null_means_retained')},
    'scientific_producer_imported': False, 'new_cone_solver_imported': False}
verified = {'study_id': mod.STUDY, 'status': 'passed', 'scientific_producer_imported': False,
    'new_helper_imported': False, 'counts': checks}
summary = {'counts': counts, 'validation': {
    'all_numeric_information_and_support_checks_passed': True,
    'new_objectives_use_own_observed_signs_only': True,
    'same_factual_state_action_reward_and_scalar': True,
    'all_eligible_logits_strictly_inside_clipping_domain': True,
    'excluded_partial_and_NoGo_solver_calls': 0,
    'residuals': {k: 0. for k in ('original_balanced_finite_gain', 'legacy_global_support',
    'uniform_global_support', 'probability_tangent_global_support', 'unit_norm',
    'single_step_equal_cost', 'observed_known_margin_safety', 'case_certificate_residual',
    'probability_tangent_identity')}},
    'interpretation': {**{k: False for k in ('new_confirmatory_hypothesis',
    'finite_probability_global_optimum_claimed', 'summed_fixed_state_gains_predict_new_trajectory',
    'actual_future_policy_relearned', 'processing_cost_equalized', 'parent_H_gain',
    'parent_H_acquisition', 'novel_input_generalization_tested', 'new_human_experiment',
    'shared_neural_mechanism_claim', 'education_effect_claim')},
    **{k: True for k in ('retrospective_descriptive_only', 'tangent_global_maximum_is_expected_integrity_property',
    'state_weighting_effect_separated_from_uniform_objective_control', 'parent_H_protection')}},
    'finite_alignment_summary': {'new_learned_performance_claim': False},
    'families': [{'seeds': list(range(10))} for _ in range(30)]}
mod.independent_gate(verified, summary, {'numeric_tolerance': 1e-8})
checks_done = ['positive_optimization_separate_from_learning']
for target, key, value in ((verified['counts'], 'independent_ambient_support_reoptimizations', 0),
    (summary['interpretation'], 'actual_future_policy_relearned', True),
    (summary['counts'], 'new_optimization_calls', 0)):
    saved = target[key]; target[key] = value
    try:
        mod.independent_gate(verified, summary, {'numeric_tolerance': 1e-8})
    except ValueError:
        checks_done.append('reject_' + key)
    else:
        raise AssertionError(key)
    finally:
        target[key] = saved
with tempfile.TemporaryDirectory() as raw:
    root = Path(raw)
    directory = root / 'results/probability_alignment_development'; directory.mkdir(parents=True)
    development = []
    for original in (repo / 'results/probability_alignment_development').iterdir():
        if original.is_file():
            target = directory / original.name; target.write_bytes(original.read_bytes())
            development.append({'path': target.relative_to(root).as_posix(), 'sha256': mod.sha(target)})
    test_name = 'results/probability_alignment_prefreeze_tests/final.xml'
    junit = root / test_name; junit.parent.mkdir()
    classes = {name: 1 for name in sorted(mod.NEW_CLASSES | mod.OLD_CLASSES)}
    junit.write_text('<testsuites><testsuite>' + ''.join('<testcase classname="' + name + '" name="fixture"/>'
        for name in classes) + '</testsuite></testsuites>')
    for name in ('results/probability_alignment_prefreeze_validation.json',
        'results/probability_alignment_baseline_preservation.json'):
        (root / name).write_text('{}')
    tests = {'status': 'passed', 'frozen_source_hashes': {}, 'parent_byte_gate': {},
        'synthetic_fixtures_only_before_freeze': True,
        'actual_new_saved_alignment_aggregation_before_freeze': 0,
        'actual_new_direction_optimizations_before_freeze': 0,
        'new_training_random_graph_calls_before_freeze': 0,
        'test_receipts': [{'path': test_name, 'sha256': mod.sha(junit), 'passed_unique_tests': 5}],
        'development_failure_artifacts': development, 'unique_passed_tests_by_class': classes,
        'unique_passed_tests': 5, 'new_unique_passed_tests': 3, 'unchanged_related_regression_passed_tests': 2}
    mod.committed = lambda *args: None
    result = mod.prefreeze_gate(root, tests, {'source_files': {}, 'gate': {}, 'source_git_commit': 'a' * 40},
        'results/probability_alignment_baseline_preservation.json', 'results/probability_alignment_prefreeze_validation.json')
    assert len(result[3]) == 1 and list(result[3].values())[0]['original_failing_cases'] == 2
    checks_done.append('exact_final_partition_and_original_48_test_2_failure_ZIP')
    tests['actual_new_direction_optimizations_before_freeze'] = 1
    try:
        mod.prefreeze_gate(root, tests, {'source_files': {}, 'gate': {}, 'source_git_commit': 'a' * 40},
            'results/probability_alignment_baseline_preservation.json', 'results/probability_alignment_prefreeze_validation.json')
    except ValueError:
        checks_done.append('reject_actual_prefreeze_optimization')
    else:
        raise AssertionError('unfrozen actual optimization accepted')
receipt = {'status': 'passed', 'checked_at_utc': datetime.now(timezone.utc).isoformat(),
    'checks': checks_done, 'actual_parent_aggregation_or_optimization_calls': 0,
    'checker_main_executed': False, 'synthetic_receipt_checks_only': True}
(base / 'work/probability_alignment_archive_fixture_validation.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
